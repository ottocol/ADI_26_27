// Sustituye estos dos valores por los de tu proyecto Supabase.
export const SUPABASE_URL = 'https://TU-PROYECTO.supabase.co';
export const SUPABASE_KEY = 'TU_PUBLISHABLE_KEY';

// Esta clave será visible en el navegador. Usa la publishable key
// (o la antigua anon key), nunca una secret key ni service_role.
